package week_14;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;
 
public class quiz_10 {
	public static void main(String[] args) {
		File f = null;
		FileReader fr = null;
		HashMap<String,String> phone;
		Scanner scanner;
		
		try {
			phone = new HashMap<String,String>();
			f = new File("c:\\temp\\phone.txt");
			fr = new FileReader(f);
			scanner = new Scanner(fr);
			
			while (scanner.hasNext()) {
				String n = scanner.next();
				String t = scanner.next();
				phone.put(n,t);
				
				System.out.println("key:"+n+"value:"+phone.get(n));
			}
			
			System.out.println("총 "+phone.size()+"개의 정보를 읽었습니다.");
			scanner.close();
			scanner=new Scanner(System.in);
			
			String temp="";
			
			while (true) {
				System.out.print("이름>>");
				temp=scanner.next();
				System.out.println(temp);
				
				if (temp.equals("그만")) {
					break;
				}
				
				String tel=phone.get(temp);
				
				if (tel==null) {
					System.out.println("찾는 이름이 없습니다.");
				}
				
				else {
					System.out.println(tel);
				}
			}
		} catch (Exception e) {

		}
	}
}