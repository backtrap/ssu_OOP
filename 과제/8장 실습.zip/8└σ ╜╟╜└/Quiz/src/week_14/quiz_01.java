package week_14;

import java.io.*;
import java.util.Scanner;
 
public class quiz_01 {
	public static void main(String[] args) {
		File f = null;
		FileWriter fw = null;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("전화번호 입력 프로그램입니다.");
		
		String temp="";
		
		try {
			f=new File("c:\\temp\\phone.txt");
			fw=new FileWriter(f);
			int c;
			while (true) {
				System.out.print("이름 전화번호 >> ");
				temp = scanner.nextLine();
				if (temp.contentEquals("그만")) {
					break;
				}
				
				fw.write(temp+"\r\n");
			}
			
			scanner.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println(f.getPath()+"에 저장하였습니다.");
	}
}