
package today_0407;

class TV{
	private int size;
	public TV(int size) { this.size = size; }
	protected int getSize() { return size; }
	}

class ColorTV extends TV {
	int n1, n2;
	
	public ColorTV(int n1, int n2) {
		super(n1);
		this.n2 = n2;
	}
	
	void printProperty() {
		System.out.println(super.getSize() + "인치 " + n2 + "컬러");
	}
}
public class quiz_01 {
	public static void main(String [] args) {
		ColorTV myTV = new ColorTV(32, 1024);
		myTV.printProperty();
	}
}
