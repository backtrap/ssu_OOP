package week_10;

import java.util.*;

class Location {
	private String name;
	private int x, y;
	public Location(String name, int x, int y) {
		this.name = name;
		this.x = x;
		this.y = y;
	}
	
	public String getName() {
		return name;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}

public class quiz7_06{
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		HashMap<String, Location> city = new HashMap<String, Location>();
		
		System.out.println("도시, 경도, 위도를 입력하세요.");
		
		for(int i = 0; i < 4; i++) {
			System.out.print(">> ");
			String text = scanner.nextLine();
			
			StringTokenizer st = new StringTokenizer(text, ",");
			String name = st.nextToken().trim();
			
			int x = Integer.parseInt(st.nextToken().trim());
			int y = Integer.parseInt(st.nextToken().trim());

			Location location = new Location(name, x, y);
			city.put(name, location);
		}
		
		Set<String> key = city.keySet();	
		Iterator<String> it = key.iterator();	
		
		System.out.println("---------------------------");
		
		while (it.hasNext()) {
			String name = it.next();
			Location location = city.get(name);	
			System.out.print(location.getName() + " ");
			System.out.print(location.getX() + " ");
			System.out.println(location.getY() + " ");
		}
		
		System.out.println("---------------------------");
		
		while(true) {
			System.out.print("도시 이름 >> ");
			String name = scanner.nextLine();
			if(name.equals("그만")) break;
			
			Location location = city.get(name); 
			if(location == null) { 
				System.out.println(name + "는 없습니다.");
			}
			
			else { 
				System.out.print(location.getName() + " ");
				System.out.print(location.getX() + " ");
				System.out.println(location.getY());
			}
		}
		
		scanner.close();
	}
}