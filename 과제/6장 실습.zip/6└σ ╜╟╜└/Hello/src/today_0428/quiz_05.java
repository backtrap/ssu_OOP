package today_0428;

import java.util.Scanner;

class Person {
	private int num1, num2, num3;
	public String name;
	
	public Person(String name) {
		this.name = name;
	}
	
	public boolean game() {
		num1 = (int)((Math.random()*3)+1);
		num2 = (int)((Math.random()*3)+1);
		num3 = (int)((Math.random()*3)+1);
		
		System.out.print("\t" + num1 + " " + num2 + " " + num3 + " ");

		if (num1==num2 && num2==num3) return true;
		else return false;
	}
}

public class quiz_05 {
	public static void main(String [] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("1번째 선수 이름>>");
		String name1 = scanner.next();
		Person person1 = new Person(name1);
		
		System.out.print("2번째 선수 이름>>");
		String name2 = scanner.next();
		Person person2 = new Person(name2);
		
		String str = scanner.nextLine();
		
		while (true) {
			System.out.print("[" + person1.name + "]:<Enter>");
			str = scanner.nextLine();
			
			if (person1.game()) {
				System.out.println(person1.name + "님이 이겼습니다!");
				break;
			}
			
			System.out.println("아쉽군요!");

			System.out.print("[" + person2.name+ "]:<Enter>");
			str = scanner.nextLine();
			
			if (person2.game()) {
				System.out.println(person2.name + "님이 이겼습니다!");
				break;
			}

			System.out.println("아쉽군요!");

		}
		
		scanner.close();
	}
}
