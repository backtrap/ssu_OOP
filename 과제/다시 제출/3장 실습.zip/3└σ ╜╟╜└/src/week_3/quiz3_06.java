package week_3;

import java.util.Scanner;

public class quiz3_06 {
   public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      int [] array = {50000, 10000, 1000, 500, 100, 50, 10, 1};
      int money;
      
      System.out.print("금액을 입력하시오 >> ");
      money = scanner.nextInt();
      
      for(int i=0; i<array.length; i++) {
         System.out.printf("%d 원 짜리 : %d개 \n",array[i], money/array[i]);
         money = money - (money / array[i])*array[i];
      }
      
      scanner.close();
   }
}