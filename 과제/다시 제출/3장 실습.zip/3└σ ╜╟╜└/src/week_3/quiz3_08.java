package week_3;

import java.util.Scanner;

public class quiz3_08 {
   public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      int array [];
      int num;
      
      System.out.print("정수 몇개? >> ");
      num = scanner.nextInt();
      
      array = new int [num];
      for(int i=0; i<array.length; i++) {
         int tmp = (int)(Math.random()*100+1);
         int n = 0;
         for(int j=0; j<array.length; j++) {
        	 if(tmp == array[j]) {
        		 n = 1;
        		 break;
        	 }
         }
         if(n==1) {
        	 i--;
        	 continue;
         }
         array[i] = tmp;
      }
      
      for(int i=0; i<array.length; i++) {
         if(i%10 == 0 && i != 0) System.out.println();
         System.out.print(array[i] + " ");
      }
      scanner.close();
   }
}