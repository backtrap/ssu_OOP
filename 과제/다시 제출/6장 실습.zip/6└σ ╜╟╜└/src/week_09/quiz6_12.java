package week_09;

import java.util.Scanner;

class Person01 {
	private int num1, num2, num3;
	public String name;
	
	public Person01(String name) {
		this.name = name;
	}
	
	public boolean game() {
		num1 = (int)((Math.random()*3)+1);
		num2 = (int)((Math.random()*3)+1);
		num3 = (int)((Math.random()*3)+1);
		
		System.out.print(" " + num1 + " " + num2 + " " + num3 + " ");

		if (num1==num2 && num2==num3) return true;
		else return false;
	}
}

public class quiz6_12 {
	public static void main(String [] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("겜블링 게임에 참여할 선수 숫자>>");
		int num = scanner.nextInt();
		
		Person01 [] Person01 = new Person01[num];
		
		for (int i=0; i<num; i++) {
			System.out.print((i+1) + "번째 선수 이름>>");
			String name = scanner.next();
			Person01[i] = new Person01(name);
		}
		
		String str = scanner.nextLine();
		
		while (true) {
			for (int i=0; i<num; i++) {
				System.out.print("[" + Person01[i].name + "]:<Enter>");
				str = scanner.nextLine();
				
				if (Person01[i].game()) {
					System.out.println(Person01[i].name + "님이 이겼습니다!");
					scanner.close();
					return ;
				}
				
				System.out.println("아쉽군요!");
			}		
		}
	}
}
